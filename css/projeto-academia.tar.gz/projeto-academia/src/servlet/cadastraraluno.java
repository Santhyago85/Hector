package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class cadastraraluno
 */
@WebServlet("/cadastraraluno")
public class cadastraraluno extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cadastraraluno() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
				String nome = request.getParameter("nome");
				String rua = request.getParameter("rua");
				String numeroCasa = request.getParameter("numeroCasa");
				String bairro = request.getParameter("bairro");
				String cidade = request.getParameter("cidade");
				String cpf = request.getParameter("cpf");
				String rg = request.getParameter("rg");
				String dataNascimento = request.getParameter("dataNascimento");
				String email = request.getParameter("email");
				String tel = request.getParameter("tel");
				String usuario = request.getParameter("usuario");
				String senha = request.getParameter("senha");
				String peso = request.getParameter("peso");
				String altura = request.getParameter("altura");
				String imc = request.getParameter("imc");
				String situacaofisica = request.getParameter("situacaofisica");
				String alimentacao = request.getParameter("alimentacao");
				String info = request.getParameter("info");

				// Alguns valores para teste de recebimento atrav�s do console
				System.out.println("Nome: " + nome);
				System.out.println("Email: " + email);
				System.out.println("CPF: " + cpf);
				System.out.println("Data de Nascimento: " + dataNascimento);
				System.out.println("F�sico: " + situacaofisica);
				System.out.println("Alimenta��o: " + alimentacao);
				System.out.println("Info: " + info);
			    
				RequestDispatcher rd = request.getRequestDispatcher("cadastroAluno.jsp");  
			    rd.forward(request, response); 

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}