package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class realizaravaliacao
 */
@WebServlet("/realizaravaliacao")
public class realizaravaliacao extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public realizaravaliacao() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//pegar valor e testar
			String op1 = request.getParameter("op1");
			String cirurgia = request.getParameter("cirurgia");
			String op2 = request.getParameter("op2");
			String doenca = request.getParameter("doenca");
			String op3 = request.getParameter("op3");
			String doencafamilia = request.getParameter("doencafamilia");
			String op4 = request.getParameter("op4");
			String op5 = request.getParameter("op5");
			String op6 = request.getParameter("op6");
			String bracoesq = request.getParameter("bracoesq");
			String bracodir = request.getParameter("bracodir");
			String busto = request.getParameter("busto");
			String abdomen = request.getParameter("abdomen");
			String cintura = request.getParameter("cintura");
			String quadril = request.getParameter("quadril");
			String coxaesq = request.getParameter("coxaesq");
			String coxadir = request.getParameter("coxadir");
			String culote = request.getParameter("culote");
			String panesq = request.getParameter("panesq");
			String pandir = request.getParameter("pandir");
			String op7 = request.getParameter("op7");
			String op8 = request.getParameter("op8");
			String op9 = request.getParameter("op9");
			String nomeins = request.getParameter("nomeins");
			String obsinst = request.getParameter("obsinst");

			System.out.println("Antecedente cirg�rgico? "+op1);
			System.out.println("Quais? "+cirurgia);
			System.out.println("Doen�as? "+op2);
			System.out.println(nomeins);
			System.out.println(obsinst);

		    RequestDispatcher rd = request.getRequestDispatcher("avaliacaofisica.jsp");  
		    rd.forward(request, response); 
		    
	} catch (Exception e) {
		e.printStackTrace();
	}
}

}