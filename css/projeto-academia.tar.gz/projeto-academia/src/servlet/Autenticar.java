package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.jni.User;

import Bean.Aluno;
import Bean.Professor;

/**
 * Servlet implementation class Autenticar
 */
@WebServlet("/Autenticar")
public class Autenticar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Autenticar() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.getSession().invalidate();
	    
		response.sendRedirect("login.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String susuario = request.getParameter("usuario");
	    String ssenha = request.getParameter("senha");
	    
	    Professor prof = new Professor();
	    prof.setUsuario(susuario);
	    prof.setSenha(ssenha);
	    prof.setNome("Marcelino");
	    
	    Aluno aluno = new Aluno();
	    aluno.setUsuario(susuario);
	    aluno.setSenha(ssenha);
	    aluno.setNome("Thaynah");

	    
	    if ((susuario != null) && (susuario.equals("professor"))  && (ssenha.equals("professor"))){
		      
	    	HttpSession sessao = request.getSession();
		 
		      sessao.setAttribute("usuario", prof);
		      request.getRequestDispatcher("indexprofessor.jsp").forward(request, response);
		      
	    }else if((susuario != null) && (susuario.equals("admin")) && (ssenha.equals("admin"))) {
		   
	    	HttpSession sessao = request.getSession();
		 
		      request.getRequestDispatcher("cadastroProfessor.jsp").forward(request, response);
		      
	    }  else if ((susuario != null) && (susuario.equals("aluno"))  && (ssenha.equals("aluno"))){
	       
		      HttpSession sessao = request.getSession();
		      
		      sessao.setAttribute("usuario", aluno);
		      request.getRequestDispatcher("ficha.jsp").forward(request, response);
		      
	    }else{
		    
	    	request.setAttribute("mensagem", "USU�RIO OU SENHA INCORRETO! </br> TENTE NOVAMENTE!");
		      
		      RequestDispatcher saida = request.getRequestDispatcher("login.jsp");
		      saida.forward(request, response);
	    }
	}

}
