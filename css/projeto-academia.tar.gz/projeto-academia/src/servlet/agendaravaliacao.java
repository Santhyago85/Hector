package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class agendaravaliacao
 */
@WebServlet("/agendaravaliacao")
public class agendaravaliacao extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public agendaravaliacao() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String dataav = request.getParameter("dataav");
			String horaav = request.getParameter("horaav");
			String obs = request.getParameter("obs");

			// Alguns valores para teste de recebimento atrav�s do console
			System.out.println("Data: " + dataav);
			System.out.println("Hora: " + horaav);
			System.out.println("Obs: " + obs);
			
		       request.setAttribute("data", dataav);  
		       request.setAttribute("hora", horaav);  

		    RequestDispatcher rd = request.getRequestDispatcher("agendaravaliacao.jsp");  
		    rd.forward(request, response); 
			       
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

	}