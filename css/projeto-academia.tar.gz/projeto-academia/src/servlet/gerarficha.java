package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class gerarficha
 */
@WebServlet("/gerarficha")
public class gerarficha extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public gerarficha() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String nomeexer = request.getParameter("nomeexer");
			String series = request.getParameter("series");
			String repiticoes = request.getParameter("repiticoes");
			String intervalo = request.getParameter("intervalo");
			String peso = request.getParameter("peso");
			String diatreino = request.getParameter("diatreino");
			String instrucao = request.getParameter("instrucao");
			
			// Alguns valores para teste de recebimento atrav�s do console
			System.out.println("Nome: " + nomeexer);
			System.out.println("series: " + series);
			System.out.println("repiticoes: " + repiticoes);
			System.out.println("instru��es: " + instrucao);
			
		    RequestDispatcher rd = request.getRequestDispatcher("gerarficha.jsp");  
		    rd.forward(request, response); 
		    
	} catch (Exception e) {
		e.printStackTrace();
	}
}

}