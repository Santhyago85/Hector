package DAO;

import java.sql.Connection;
import java.sql.SQLException;

public class TestaConexao {

    public static void main(String[] args) {
        try {
            Connection con = ConnectionFactory.getConnection();
            System.out.println("Conectado!");
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}