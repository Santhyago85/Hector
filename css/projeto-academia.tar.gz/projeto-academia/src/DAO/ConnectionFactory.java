package DAO;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class ConnectionFactory {
    public static void main(String[] args) throws SQLException {
        Connection conexao = (Connection) DriverManager.getConnection(
          "jdbc:mysql://localhost/academia");
        System.out.println("Conectado!");
        conexao.close();
    }


}