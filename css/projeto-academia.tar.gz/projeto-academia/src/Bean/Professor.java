package Bean;

public class Professor {
  private int id_professor;
  private String nome;
  private String endereco;
  private String cpf;
  private String rg;
  private String email;
  private String cref;
  private String especialidade;
  private String usuario;
  private String senha;
  private String tipo;
  
  public Professor() {}
  
  public int getId_professor() { return id_professor; }
  
  public void setId_professor(int id_professor) {
    this.id_professor = id_professor;
  }
  
  public String getNome() { return nome; }
  
  public void setNome(String nome) {
    this.nome = nome;
  }
  
  public String getEndereco() { return endereco; }
  
  public void setEndereco(String endereco) {
    this.endereco = endereco;
  }
  
  public String getCpf() { return cpf; }
  
  public void setCpf(String cpf) {
    this.cpf = cpf;
  }
  
  public String getRg() { return rg; }
  
  public void setRg(String rg) {
    this.rg = rg;
  }
  
  public String getEmail() { return email; }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getCref() { return cref; }
  
  public void setCref(String cref) {
    this.cref = cref;
  }
  
  public String getEspecialidade() { return especialidade; }
  
  public void setEspecialidade(String especialidade) {
    this.especialidade = especialidade;
  }
  
  public String getUsuario() { return usuario; }
  
  public void setUsuario(String usuario) {
    this.usuario = usuario;
  }
  
  public String getSenha() { return senha; }
  
  public void setSenha(String senha) {
    this.senha = senha;
  }
  
  public String getTipo() { return tipo; }
  
  public void setTipo(String tipo) {
    this.tipo = tipo;
  }
}
