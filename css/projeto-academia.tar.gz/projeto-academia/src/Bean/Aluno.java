package Bean;

public class Aluno {
  private int id_aluno;
  private int professor;
  private String nome;
  private String endereco;
  private String cpf;
  private String rg;
  private String data_nasc;
  private String email;
  private String telefone;
  private String usuario;
  private String senha;
  private double peso;
  private double altura;
  private String inf_adc;
  private String tipo;
  
  public Aluno() {}
  
  public int getId_aluno() { return id_aluno; }
  
  public void setId_aluno(int id_aluno) {
    this.id_aluno = id_aluno;
  }
  
  public int getProfessor() { return professor; }
  
  public void setProfessor(int professor) {
    this.professor = professor;
  }
  
  public String getNome() { return nome; }
  
  public void setNome(String nome) {
    this.nome = nome;
  }
  
  public String getEndereco() { return endereco; }
  
  public void setEndereco(String endereco) {
    this.endereco = endereco;
  }
  
  public String getCpf() { return cpf; }
  
  public void setCpf(String cpf) {
    this.cpf = cpf;
  }
  
  public String getRg() { return rg; }
  
  public void setRg(String rg) {
    this.rg = rg;
  }
  
  public String getData_nasc() { return data_nasc; }
  
  public void setData_nasc(String data_nasc) {
    this.data_nasc = data_nasc;
  }
  
  public String getEmail() { return email; }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getTelefone() { return telefone; }
  
  public void setTelefone(String telefone) {
    this.telefone = telefone;
  }
  
  public String getUsuario() { return usuario; }
  
  public void setUsuario(String usuario) {
    this.usuario = usuario;
  }
  
  public String getSenha() { return senha; }
  
  public void setSenha(String senha) {
    this.senha = senha;
  }
  
  public double getPeso() { return peso; }
  
  public void setPeso(double peso) {
    this.peso = peso;
  }
  
  public double getAltura() { return altura; }
  
  public void setAltura(double altura) {
    this.altura = altura;
  }
  
  public String getInf_adc() { return inf_adc; }
  
  public void setInf_adc(String inf_adc) {
    this.inf_adc = inf_adc;
  }
  
  public String getTipo() { return tipo; }
  
  public void setTipo(String tipo) {
    this.tipo = tipo;
  }
}
