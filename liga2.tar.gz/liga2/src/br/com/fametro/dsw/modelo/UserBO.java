package br.com.fametro.dsw.modelo;

import javax.servlet.http.HttpServletRequest;

public class UserBO {
	public User verificaLogin(HttpServletRequest request, UserDAO databaseadapter)
	throws NegocioException{
		try{
			String nome = request.getParameter("login");
			String senha = request.getParameter("senha");
			
			User user = new User();
			user.setNome(nome);
			user.setSenha(senha);
			
			user = databaseadapter.validarUsuario(user);
			return user;
		}catch (PersistenciaException e) {
			e.printStackTrace();
			throw new NegocioException(e);
		}
	}
}
