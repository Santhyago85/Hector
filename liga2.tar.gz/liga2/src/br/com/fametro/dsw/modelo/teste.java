package br.com.fametro.dsw.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class teste {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		try{
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      String url = "jdbc:derby://localhost:1527/usuarios";
	      Connection con = DriverManager.getConnection(url, "adm", "86801404");
	     System.out.println("conexão feita com sucesso!");
	     
		}catch(SQLException e){
		      System.out.println("A conex�o falhou... " + e.getMessage());

		}
	   }

}
	


