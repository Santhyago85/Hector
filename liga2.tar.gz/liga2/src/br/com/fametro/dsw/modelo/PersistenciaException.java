package br.com.fametro.dsw.modelo;

public class PersistenciaException extends Exception {

}
