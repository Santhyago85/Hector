package br.com.fametro.dsw.modelo;

import java.lang.Exception;

public class NegocioException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public NegocioException(PersistenciaException e) {
		super("Usuario ou senha inválidos!");
	}
}
