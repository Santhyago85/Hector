package br.com.fametro.dsw.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;



public class UserDAO {
	public DataSource datasource;
	
	public UserDAO(DataSource datasource) {
		this.datasource = datasource;
	}

	public User validarUsuario(User user) throws PersistenciaException {
		Connection conexao = null;
		try{
			if (datasource != null){
				conexao = datasource.getConnection();
			}else{
				System.out.println("Falha no datasource!");
			}
			
			String sql = "SELECT * FROM USUARIOS WHERE NOME = ? AND SENHA = ?";
			PreparedStatement statement = conexao.prepareStatement(sql);
			statement.setString(1, user.getNome());
			statement.setString(2, user.getSenha());
			
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			user.setId(resultSet.getInt("id"));
			user.setNome(resultSet.getString("nome"));
			user.setSobrenome(resultSet.getString("sobrenome"));
			user.setEmail(resultSet.getString("email"));
			return user;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new PersistenciaException();
		}
		
	}
	
	public void adiciona(User user) throws ProblemaAoInsertUserException {
		Connection conexao = null;
		
		try{
			conexao = datasource.getConnection();
			String sql = "INSERT INTO USUARIOS (NOME, SOBRENOME, SENHA, EMAIL) VALUES (?, ?, ?, ?)";
			PreparedStatement stmt = conexao.prepareStatement(sql);
			
			stmt.setString(1, user.getNome());
			stmt.setString(2, user.getSobrenome());
			stmt.setString(3, user.getSenha());
			stmt.setString(4, user.getEmail());

			stmt.execute();
			stmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new ProblemaAoInsertUserException();
		}
	}
	
}