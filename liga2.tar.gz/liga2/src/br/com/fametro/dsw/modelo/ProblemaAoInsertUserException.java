package br.com.fametro.dsw.modelo;

public class ProblemaAoInsertUserException extends Exception {

}
