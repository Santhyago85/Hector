package br.com.fametro.dsw.servlets;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import br.com.fametro.dsw.modelo.NegocioException;
import br.com.fametro.dsw.modelo.User;
import br.com.fametro.dsw.modelo.UserBO;
import br.com.fametro.dsw.modelo.UserDAO;

/**
 * Servlet implementation class ProcessaLogin
 */
@WebServlet("/ProcessaLogin")
public class ProcessaLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Resource(name = "jdbc/acessDB")
	public DataSource datasource;
	
		private UserDAO databaseadapter;
		public void init() throws ServletException {
			databaseadapter = new UserDAO(datasource);
		}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessaLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);

	}
	
	private void processRequest (HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		ServletContext context = getServletContext();
		User user = new User();
		// Extrai o nome e a senha do formulário da página login.jsp
		try {
			// Verifica o login e o password e cria a sessão;
			user = new UserBO().verificaLogin(request, databaseadapter);

			HttpSession session = request.getSession();
			session.setAttribute("USUARIO", user);
			// Transfere para a servlet processar a lista de users.
			context.getRequestDispatcher("/ListaUsuarios").forward(request, response);

		} catch (NegocioException e) {
			e.printStackTrace();
			request.setAttribute("MENSAGEM", e.getMessage());
			context.getRequestDispatcher("/login.jsp").forward(request, response);
		} 
	}

}
